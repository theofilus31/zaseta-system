import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout.jsx';
import axiosClient from '../api/axiosClient.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useNotification } from '../context/NotificationContext.jsx';
import Card, { CardHeader } from '../components/ui/Card.jsx';
import Button from '../components/ui/Button.jsx';
import PageHeader, { MasterDataLayout } from '../components/ui/PageHeader.jsx';
import EmptyState from '../components/ui/EmptyState.jsx';
import PasswordInput from '../components/ui/PasswordInput.jsx';
import { Badge } from '../components/ui/StatusBadge.jsx';
import { TextField, SelectField, FormError } from '../components/ui/Form.jsx';

const EMPTY_FORM = { id: null, username: '', name: '', email: '', password: '', roleId: '', status: 'active' };

const ROLE_LABEL = { admin: 'Administrator', it_staff: 'Staf IT', viewer: 'Peninjau' };
const ROLE_TONE = { admin: 'danger', it_staff: 'info', viewer: 'neutral' };

export default function UserManagement() {
  const { user: currentUser } = useAuth();
  const { pushSuccess, pushError } = useNotification();

  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [isEdit, setIsEdit] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  function load() {
    axiosClient.get('/users').then((res) => setUsers(res.data));
  }
  useEffect(() => {
    load();
    axiosClient.get('/roles').then((res) => setRoles(res.data));
  }, []);

  function startEdit(u) {
    setIsEdit(true);
    setForm({ id: u.id, username: u.username, name: u.name, email: u.email, password: '', roleId: u.role_id, status: u.status });
    setError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function resetForm() {
    setIsEdit(false);
    setForm(EMPTY_FORM);
    setError('');
  }

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      if (isEdit) {
        const payload = {
          username: form.username, name: form.name, email: form.email,
          roleId: form.roleId, status: form.status,
        };
        /* Kata sandi hanya dikirim kalau memang diisi — kalau kosong, sandi
           lama pengguna tetap berlaku. */
        if (form.password) payload.password = form.password;
        await axiosClient.put(`/users/${form.id}`, payload);
        pushSuccess(`Pengguna "${form.name}" berhasil diperbarui.`);
      } else {
        await axiosClient.post('/users', form);
        pushSuccess(`Pengguna "${form.name}" berhasil ditambahkan.`);
      }
      resetForm();
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Gagal menyimpan pengguna.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(u) {
    if (!confirm(`Hapus pengguna "${u.name}"? Tindakan ini tidak bisa dibatalkan.`)) return;
    try {
      await axiosClient.delete(`/users/${u.id}`);
      if (form.id === u.id) resetForm();
      load();
      pushSuccess(`Pengguna "${u.name}" dihapus.`);
    } catch (err) {
      pushError(err.response?.data?.message || 'Gagal menghapus pengguna.');
    }
  }

  return (
    <Layout>
      <PageHeader
        eyebrow="Administrasi"
        title="Manajemen Pengguna"
        description="Kelola akun dan hak akses. Administrator dapat mengelola semua data; Staf IT mengelola aset; Peninjau hanya dapat melihat."
      />

      <MasterDataLayout
        form={
          <Card as="form" onSubmit={handleSubmit} className={isEdit ? 'ring-2 ring-brand-500/20' : ''}>
            <CardHeader
              title={isEdit ? 'Ubah Pengguna' : 'Tambah Pengguna'}
              description={isEdit ? `Sedang mengubah akun "${form.name}".` : undefined}
              icon={(p) => <i {...p} className="fas fa-user-shield text-xs" />}
            />

            <div className="space-y-4">
              <TextField
                label="Nama Lengkap" name="name" required
                value={form.name} onChange={handleChange}
                placeholder="Mis. Budi Santoso"
              />

              <TextField
                label="Nama Pengguna" name="username" required
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value.toLowerCase() })}
                className="font-mono"
                autoCapitalize="none" autoCorrect="off"
                placeholder="budi.santoso"
                hint="Dipakai untuk masuk. Huruf kecil, tanpa spasi."
              />

              <TextField
                label="Surel" name="email" type="email" required
                value={form.email} onChange={handleChange}
                placeholder="budi@perusahaan.com"
              />

              <PasswordInput
                label={isEdit ? 'Kata Sandi Baru' : 'Kata Sandi'}
                name="password"
                value={form.password}
                onChange={handleChange}
                required={!isEdit}
                autoComplete="new-password"
                placeholder={isEdit ? 'Kosongkan jika tidak diganti' : 'Minimal 8 karakter'}
                hint={isEdit ? 'Biarkan kosong agar kata sandi lama tetap berlaku.' : undefined}
              />

              <SelectField label="Peran" name="roleId" required value={form.roleId} onChange={handleChange}>
                <option value="">Pilih peran</option>
                {roles.map((r) => (
                  <option key={r.id} value={r.id}>{ROLE_LABEL[r.name] || r.name}</option>
                ))}
              </SelectField>

              <SelectField label="Status Akun" name="status" value={form.status} onChange={handleChange}>
                <option value="active">Aktif</option>
                <option value="inactive">Nonaktif</option>
              </SelectField>

              <FormError>{error}</FormError>

              <div className="flex gap-2">
                <Button type="submit" loading={saving} className="flex-1">
                  {saving ? 'Menyimpan…' : isEdit ? 'Simpan Perubahan' : 'Simpan Pengguna'}
                </Button>
                {isEdit && (
                  <Button type="button" variant="secondary" onClick={resetForm}>Batal</Button>
                )}
              </div>
            </div>
          </Card>
        }
        table={
          <Card padded={false} className="overflow-hidden">
            <CardHeader
              title="Daftar Pengguna"
              description={`${users.length} akun terdaftar`}
              bordered
            />

            {users.length === 0 ? (
              <EmptyState
                icon="fa-users"
                title="Belum ada pengguna"
                description="Tambahkan akun pertama melalui formulir di samping."
              />
            ) : (
              <div className="overflow-x-auto scrollbar-slim">
                <table className="table-base min-w-[720px]">
                  <thead>
                    <tr>
                      <th>Pengguna</th>
                      <th>Surel</th>
                      <th>Peran</th>
                      <th>Status</th>
                      <th className="w-24 text-right"><span className="sr-only">Aksi</span></th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => {
                      const isSelf = u.id === currentUser.id;
                      return (
                        <tr key={u.id} className={form.id === u.id ? 'is-selected' : ''}>
                          <td>
                            <div className="flex items-center gap-3 min-w-0">
                              <span
                                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full
                                           bg-gradient-to-br from-info-500 to-brand-500 text-white text-xs font-semibold"
                                aria-hidden="true"
                              >
                                {u.name?.[0]?.toUpperCase() || '?'}
                              </span>
                              <div className="min-w-0">
                                <p className="font-medium text-ink-800 truncate">
                                  {u.name}
                                  {isSelf && <span className="ml-1.5 text-[11px] font-normal text-ink-400">(Anda)</span>}
                                </p>
                                <p className="text-[11px] font-mono text-ink-400 truncate">{u.username}</p>
                              </div>
                            </div>
                          </td>

                          <td className="text-ink-500">{u.email}</td>

                          <td>
                            <Badge tone={ROLE_TONE[u.role] || 'neutral'} size="sm">
                              {ROLE_LABEL[u.role] || u.role}
                            </Badge>
                          </td>

                          <td>
                            <Badge tone={u.status === 'active' ? 'brand' : 'neutral'} size="sm">
                              {u.status === 'active' ? 'Aktif' : 'Nonaktif'}
                            </Badge>
                          </td>

                          <td className="text-right whitespace-nowrap">
                            <button
                              onClick={() => startEdit(u)}
                              title={`Ubah ${u.name}`} aria-label={`Ubah ${u.name}`}
                              className="h-8 w-8 inline-flex items-center justify-center rounded-lg
                                         text-ink-400 hover:text-brand-600 hover:bg-brand-50 transition-colors"
                            >
                              <i className="fas fa-pen text-[12px]" aria-hidden="true" />
                            </button>
                            {/* Akun sendiri sengaja tidak bisa dihapus — mencegah
                                admin terakhir mengunci dirinya keluar dari sistem. */}
                            {!isSelf && (
                              <button
                                onClick={() => handleDelete(u)}
                                title={`Hapus ${u.name}`} aria-label={`Hapus ${u.name}`}
                                className="h-8 w-8 inline-flex items-center justify-center rounded-lg
                                           text-ink-300 hover:text-danger-600 hover:bg-danger-50 transition-colors"
                              >
                                <i className="fas fa-trash-can text-[13px]" aria-hidden="true" />
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        }
      />
    </Layout>
  );
}
