import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Layout from '../components/Layout.jsx';
import axiosClient from '../api/axiosClient.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useNotification } from '../context/NotificationContext.jsx';
import Card from '../components/ui/Card.jsx';
import Button from '../components/ui/Button.jsx';
import PageHeader from '../components/ui/PageHeader.jsx';
import Pagination from '../components/ui/Pagination.jsx';
import AssetFilterBar from '../components/assets/AssetFilterBar.jsx';
import AssetTable from '../components/assets/AssetTable.jsx';
import AssetCardList from '../components/assets/AssetCardList.jsx';
import ImportCsvModal from '../components/ImportCsvModal.jsx';
import MoveAssetModal from '../components/assets/MoveAssetModal.jsx';
import SellAssetModal from '../components/assets/SellAssetModal.jsx';

export default function AssetList() {
  const { hasRole } = useAuth();
  const { pushError, pushSuccess } = useNotification();
  const [searchParams] = useSearchParams();

  const [assets, setAssets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [assetTypes, setAssetTypes] = useState([]);
  const [search, setSearch] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [assetTypeId, setAssetTypeId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [subLocationId, setSubLocationId] = useState('');
  const [status, setStatus] = useState(searchParams.get('status') || '');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ totalPages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(new Set());
  const [showImport, setShowImport] = useState(false);
  const [showMoveModal, setShowMoveModal] = useState(false);
  const [showSellModal, setShowSellModal] = useState(null); // null | 'dijual' | 'terjual'

  useEffect(() => {
    axiosClient.get('/categories').then((res) => setCategories(res.data));
    axiosClient.get('/asset-types').then((res) => setAssetTypes(res.data));
  }, []);

  function reloadAssets() {
    setLoading(true);
    return axiosClient
      .get('/assets', {
        params: { search, categoryId, assetTypeId, locationId, subLocationId, status, page, limit: 10 },
      })
      .then((res) => {
        setAssets(res.data.data);
        setPagination(res.data.pagination);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    reloadAssets();
  }, [search, categoryId, assetTypeId, locationId, subLocationId, status, page]);

  /* Setiap perubahan filter mengembalikan ke halaman 1 dan mengosongkan
     pilihan — kalau tidak, aset yang sudah tidak tampil bisa ikut terkena
     aksi massal tanpa terlihat. */
  function updateFilter(setter) {
    return (value) => { setter(value); setPage(1); setSelected(new Set()); };
  }

  function toggleSelect(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function toggleSelectAll(checked) {
    setSelected(checked ? new Set(assets.map((a) => a.id)) : new Set());
  }

  async function handleBulkStatusChange(newStatus) {
    const ids = Array.from(selected);
    if (!confirm(`Ubah status ${ids.length} aset terpilih?`)) return;
    try {
      await Promise.all(ids.map((id) => axiosClient.put(`/assets/${id}`, { status: newStatus })));
      setSelected(new Set());
      await reloadAssets();
      pushSuccess(`Status ${ids.length} aset berhasil diubah.`);
    } catch (err) {
      pushError(err.response?.data?.message || 'Gagal mengubah status sebagian/semua aset.');
    }
  }

  /* Pindahkan aset terpilih ke lokasi/sub lokasi baru. Status otomatis jadi
     "dipindah", sedangkan id & kode aset TIDAK berubah. */
  async function handleMoveAssets({ locationId: destLocationId, subLocationId: destSubLocationId }) {
    const ids = Array.from(selected);
    await Promise.all(ids.map((id) => axiosClient.put(`/assets/${id}`, {
      status: 'dipindah', locationId: destLocationId, subLocationId: destSubLocationId,
    })));
    setSelected(new Set());
    setShowMoveModal(false);
    await reloadAssets();
    pushSuccess(`${ids.length} aset berhasil dipindahkan.`);
  }

  /* Tandai aset terpilih sebagai "Dijual" (butuh saleValueNet) atau "Terjual"
     (butuh soldPrice, soldDate opsional), sesuai mode modal yang aktif. */
  async function handleSellAssets(payload) {
    const ids = Array.from(selected);
    const mode = showSellModal;
    const body = mode === 'dijual'
      ? { status: 'dijual', saleValueNet: payload.saleValueNet }
      : { status: 'terjual', soldPrice: payload.soldPrice, soldDate: payload.soldDate };
    await Promise.all(ids.map((id) => axiosClient.put(`/assets/${id}`, body)));
    setSelected(new Set());
    setShowSellModal(null);
    await reloadAssets();
    pushSuccess(`${ids.length} aset ditandai ${mode === 'dijual' ? 'Dijual' : 'Terjual'}.`);
  }

  async function handleBulkDelete() {
    const ids = Array.from(selected);
    if (!confirm(`Hapus ${ids.length} aset terpilih? Tindakan ini tidak bisa dibatalkan.`)) return;
    try {
      await Promise.all(ids.map((id) => axiosClient.delete(`/assets/${id}`)));
      setSelected(new Set());
      await reloadAssets();
      pushSuccess(`${ids.length} aset berhasil dihapus.`);
    } catch (err) {
      pushError(err.response?.data?.message || 'Gagal menghapus sebagian/semua aset.');
    }
  }

  async function handleDeleteOne(asset) {
    if (!confirm(`Hapus aset "${asset.name}"? Tindakan ini tidak bisa dibatalkan.`)) return;
    try {
      await axiosClient.delete(`/assets/${asset.id}`);
      await reloadAssets();
      pushSuccess(`Aset "${asset.name}" berhasil dihapus.`);
    } catch (err) {
      pushError(err.response?.data?.message || 'Gagal menghapus aset.');
    }
  }

  const canManage = hasRole('admin', 'it_staff');
  const isAdmin = hasRole('admin');

  return (
    <Layout>
      <PageHeader
        title="Daftar Aset"
        description={
          typeof pagination.total === 'number'
            ? `${pagination.total} aset terdaftar di sistem.`
            : 'Seluruh aset IT yang terdaftar di sistem.'
        }
        actions={
          <>
            <Button to="/cetak-barcode-massal" variant="secondary" size="sm">
              <i className="fas fa-print text-xs" aria-hidden="true" />
              <span className="hidden sm:inline">Cetak Label</span>
            </Button>
            {canManage && (
              <>
                <Button variant="secondary" size="sm" onClick={() => setShowImport(true)}>
                  <i className="fas fa-file-import text-xs" aria-hidden="true" />
                  <span className="hidden sm:inline">Impor CSV</span>
                </Button>
                <Button to="/assets/new" size="sm">
                  <i className="fas fa-plus text-xs" aria-hidden="true" /> Tambah Aset
                </Button>
              </>
            )}
          </>
        }
      />

      <AssetFilterBar
        search={search} onSearchChange={updateFilter(setSearch)}
        categoryId={categoryId} onCategoryChange={updateFilter(setCategoryId)} categories={categories}
        assetTypeId={assetTypeId} onAssetTypeChange={updateFilter(setAssetTypeId)} assetTypes={assetTypes}
        locationId={locationId} onLocationChange={updateFilter(setLocationId)}
        subLocationId={subLocationId} onSubLocationChange={updateFilter(setSubLocationId)}
        status={status} onStatusChange={updateFilter(setStatus)}
        totalItems={pagination.total}
        selectedCount={canManage ? selected.size : 0}
        onBulkStatusChange={handleBulkStatusChange}
        onClearSelection={() => setSelected(new Set())}
        canDelete={isAdmin}
        onBulkDelete={handleBulkDelete}
        onMoveAssets={() => setShowMoveModal(true)}
        onSellAssets={() => setShowSellModal('dijual')}
        onMarkSoldAssets={() => setShowSellModal('terjual')}
      />

      <Card padded={false} className="overflow-hidden">
        <AssetTable
          assets={assets} loading={loading} selected={selected}
          onToggleSelect={toggleSelect} onToggleSelectAll={toggleSelectAll}
          canDelete={isAdmin} onDelete={handleDeleteOne}
        />
        <AssetCardList
          assets={assets} loading={loading} selected={selected} onToggleSelect={toggleSelect}
        />
      </Card>

      <Pagination
        page={page}
        totalPages={pagination.totalPages}
        totalItems={pagination.total}
        onChange={setPage}
      />

      {showMoveModal && (
        <MoveAssetModal
          count={selected.size}
          onConfirm={handleMoveAssets}
          onClose={() => setShowMoveModal(false)}
        />
      )}

      {showSellModal && (
        <SellAssetModal
          mode={showSellModal}
          count={selected.size}
          onConfirm={handleSellAssets}
          onClose={() => setShowSellModal(null)}
        />
      )}

      {showImport && (
        <ImportCsvModal
          title="Impor Aset dari CSV"
          expectedColumns={['id', 'location', 'sub_location', 'category', 'name', 'asset_type', 'condition', 'spec_detail', 'brand', 'model', 'status', 'sale_value_net', 'sold_date', 'sold_price']}
          helpText={
            'Kode aset TIDAK diisi manual — server otomatis menyusunnya dari location + sub_location + category + id. ' +
            'Hanya location dan category yang WAJIB diisi, dan keduanya harus SUDAH terdaftar/aktif di sistem (menu Lokasi & Kode Barang/Aset). ' +
            'sub_location opsional. id (nomor urut aset) boleh dikosongkan agar diisi otomatis oleh server. ' +
            'Kolom lain (name, asset_type, condition, spec_detail, brand, model, status) boleh dikosongkan dan dilengkapi belakangan lewat Ubah Aset — ' +
            'kalau kosong: name dibuatkan otomatis, condition default Baik, status default idle. ' +
            'asset_type (kalau diisi) wajib sudah ada di menu Kategori Aset. condition diisi Baik / Rusak Ringan / Rusak Berat. ' +
            'status diisi salah satu: dijual, terjual, dipindah, dipakai, idle. ' +
            'sale_value_net WAJIB diisi kalau status = dijual (angka, tanpa titik/koma). ' +
            'sold_price WAJIB diisi kalau status = terjual (angka); sold_date opsional (format YYYY-MM-DD). ' +
            'Ketiga kolom ini boleh dikosongkan untuk status dipakai/idle/dipindah.'
          }
          sampleRows={[
            ['1', 'HO', '', 'LAPTOP', 'Laptop Marketing 1', 'Elektronik', 'Baik', '1. Intel i5\n2. RAM 8GB\n3. SSD 256GB', 'Dell', 'Latitude 5420', 'dipakai', '', '', ''],
            ['2', 'HO', 'GA', 'MEJA', 'Meja Kerja Staff', 'Furniture', 'Rusak Ringan', '', 'Informa', '-', 'idle', '', '', ''],
            ['', 'HO', '', 'LAPTOP', 'Laptop Marketing Lama', 'Elektronik', 'Rusak Ringan', '', 'Dell', 'Latitude 5410', 'dijual', '3500000', '', ''],
            ['', 'HO', '', 'LAPTOP', '', '', '', '', '', '', '', '', '', ''],
          ]}
          templateFileName="template-import-aset.csv"
          onUpload={async (file) => {
            const formData = new FormData();
            formData.append('file', file);
            const res = await axiosClient.post('/assets/import', formData, {
              headers: { 'Content-Type': 'multipart/form-data' },
            });
            return res.data;
          }}
          onImported={reloadAssets}
          onClose={() => setShowImport(false)}
        />
      )}
    </Layout>
  );
}
