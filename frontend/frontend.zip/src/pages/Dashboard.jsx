import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../components/Layout.jsx';
import axiosClient from '../api/axiosClient.js';
import { useAuth } from '../context/AuthContext.jsx';
import Card, { CardHeader } from '../components/ui/Card.jsx';
import Button from '../components/ui/Button.jsx';
import StatCard from '../components/ui/StatCard.jsx';
import PageHeader from '../components/ui/PageHeader.jsx';
import EmptyState from '../components/ui/EmptyState.jsx';
import { STATUS_CONFIG } from '../components/ui/StatusBadge.jsx';
import { SkeletonCards, Skeleton } from '../components/ui/Skeleton.jsx';

/* ---------- Ikon KPI (inline supaya tidak bergantung pada Font Awesome) ---------- */
const stroke = { fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' };

const TotalIcon = (p) => (
  <svg {...p} viewBox="0 0 24 24" {...stroke}><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /><path d="M3 12h18" /></svg>
);
const InUseIcon = (p) => (
  <svg {...p} viewBox="0 0 24 24" {...stroke}><rect x="2" y="4" width="20" height="13" rx="2" /><path d="M8 21h8M12 17v4" /></svg>
);
const IdleIcon = (p) => (
  <svg {...p} viewBox="0 0 24 24" {...stroke}><path d="m3 8 9-5 9 5v8l-9 5-9-5V8Z" /><path d="m3 8 9 5 9-5M12 13v8" /></svg>
);
const SoldIcon = (p) => (
  <svg {...p} viewBox="0 0 24 24" {...stroke}><path d="M20.6 12.6 12 21.2l-8.6-8.6a5 5 0 0 1 0-7.1 5 5 0 0 1 7.1 0L12 6.8l1.5-1.4a5 5 0 0 1 7.1 7.1Z" opacity=".35" /><path d="M7.5 7.5h.01" /><path d="m3 3 18 18" /></svg>
);
const PlusIcon = (p) => (
  <svg {...p} viewBox="0 0 24 24" {...stroke}><path d="M12 5v14M5 12h14" /></svg>
);

/* Urutan status di donut & legenda. Warna diambil dari STATUS_CONFIG supaya
   grafik, lencana, dan tabel tidak pernah berbeda warna untuk status yang sama. */
const DONUT_ORDER = ['dipakai', 'idle', 'dijual', 'terjual', 'dipindah'];

/**
 * Donut status aset. Digambar manual dengan stroke-dasharray — tidak perlu
 * pustaka grafik untuk satu bagan sesederhana ini.
 */
function StatusDonut({ statusMap, total }) {
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  const segments = DONUT_ORDER.map((key) => {
    const cfg = STATUS_CONFIG[key];
    const value = Number(statusMap[key] || 0);
    const fraction = total > 0 ? value / total : 0;
    const segment = {
      key,
      label: cfg.label,
      color: cfg.chart,
      value,
      percent: fraction * 100,
      dash: fraction * circumference,
      offset: -cumulative * circumference,
    };
    cumulative += fraction;
    return segment;
  });

  const drawn = segments.filter((s) => s.value > 0);

  return (
    <div>
      <div className="relative mx-auto w-44 h-44">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90" role="img" aria-label="Komposisi status aset">
          <circle cx="50" cy="50" r={radius} fill="none" stroke="#f1f5f9" strokeWidth="12" />
          {drawn.map((s) => (
            <circle
              key={s.key}
              cx="50" cy="50" r={radius} fill="none"
              stroke={s.color}
              strokeWidth="12"
              strokeLinecap="butt"
              strokeDasharray={`${s.dash} ${circumference}`}
              strokeDashoffset={s.offset}
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-[28px] font-bold text-ink-900 leading-none tabular-nums">{total}</span>
          <span className="text-[11px] text-ink-400 mt-1">Total Aset</span>
        </div>
      </div>

      {/* Legenda sekaligus jadi tautan ke daftar aset yang sudah terfilter */}
      <ul className="mt-6 space-y-1">
        {segments.map((s) => (
          <li key={s.key}>
            <Link
              to={`/assets?status=${s.key}`}
              className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 -mx-2 hover:bg-ink-50 transition-colors group"
            >
              <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: s.color }} aria-hidden="true" />
              <span className="text-[13px] text-ink-600 group-hover:text-ink-900 transition-colors flex-1 truncate">
                {s.label}
              </span>
              <span className="text-[13px] font-semibold text-ink-800 tabular-nums shrink-0">{s.value}</span>
              <span className="text-[11px] text-ink-400 tabular-nums w-10 text-right shrink-0">
                {s.percent.toFixed(0)}%
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* Terjemahan aksi & entitas dari audit log ke bahasa yang enak dibaca. */
const ACTION_LABEL = {
  create: 'menambahkan', update: 'memperbarui', delete: 'menghapus',
  login: 'masuk ke sistem', scan: 'memindai', import: 'mengimpor',
  regenerate_qr: 'membuat ulang Kode QR',
};
const ENTITY_LABEL = {
  asset: 'aset', asset_category: 'kode barang/aset', asset_type: 'kategori aset',
  location: 'lokasi', sub_location: 'sub lokasi', custom_field: 'bidang kustom',
  user: 'pengguna', qr_code: 'Kode QR',
};
const ACTION_TONE = {
  create: 'bg-brand-50 text-brand-600',
  update: 'bg-info-50 text-info-600',
  delete: 'bg-danger-50 text-danger-600',
  import: 'bg-accent-50 text-accent-600',
};
const ACTION_ICON = {
  create: 'fa-plus', update: 'fa-pen', delete: 'fa-trash-can',
  import: 'fa-file-import', scan: 'fa-qrcode', login: 'fa-right-to-bracket',
};

function ActivityItem({ entry }) {
  const action = ACTION_LABEL[entry.action] || entry.action;
  const entity = ENTITY_LABEL[entry.entity_type] || entry.entity_type;
  const tone = ACTION_TONE[entry.action] || 'bg-ink-100 text-ink-500';
  const icon = ACTION_ICON[entry.action] || 'fa-circle-dot';

  return (
    <li className="flex gap-3 py-3 first:pt-0 last:pb-0">
      <span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${tone}`}>
        <i className={`fas ${icon} text-[11px]`} aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[13px] text-ink-600 leading-snug">
          <span className="font-semibold text-ink-800">{entry.user_name || 'Sistem'}</span>{' '}
          {action} {entity}
          {entry.entity_id && (
            <span className="font-mono text-ink-400"> #{entry.entity_id}</span>
          )}
        </p>
        <p className="text-[11px] text-ink-400 mt-0.5">
          {new Date(entry.created_at).toLocaleString('id-ID', {
            day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
          })}
        </p>
      </div>
    </li>
  );
}

export default function Dashboard() {
  const { user, hasRole } = useAuth();
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosClient.get('/dashboard/summary')
      .then((res) => setSummary(res.data))
      .finally(() => setLoading(false));
  }, []);

  const statusMap = Object.fromEntries((summary?.byStatus || []).map((s) => [s.status, Number(s.total)]));
  const total = Number(summary?.totalAssets || 0);
  const categories = (summary?.byCategory || []).filter((c) => Number(c.total) > 0);
  const maxCategory = Math.max(1, ...categories.map((c) => Number(c.total)));

  const pct = (n) => (total ? (n / total) * 100 : 0);
  const soldTotal = (statusMap.dijual || 0) + (statusMap.terjual || 0);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 11) return 'Selamat pagi';
    if (h < 15) return 'Selamat siang';
    if (h < 19) return 'Selamat sore';
    return 'Selamat malam';
  })();

  return (
    <Layout>
      <PageHeader
        eyebrow={greeting}
        title={user?.name ? `Ringkasan aset, ${user.name.split(' ')[0]}` : 'Ringkasan Aset'}
        description="Kondisi seluruh aset IT perusahaan dalam satu tampilan."
        actions={
          <>
            {hasRole('admin', 'it_staff') && (
              <Button to="/assets/new" size="sm">
                <PlusIcon className="h-3.5 w-3.5" /> Tambah Aset
              </Button>
            )}
            <Button to="/assets" variant="secondary" size="sm">
              Lihat Semua Aset
            </Button>
          </>
        }
      />

      {loading || !summary ? (
        <div className="space-y-5">
          <SkeletonCards count={4} />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <Card><Skeleton className="h-4 w-32 mb-6" /><Skeleton className="h-44 w-44 mx-auto rounded-full" /></Card>
            <Card className="lg:col-span-2"><Skeleton className="h-4 w-40 mb-6" /><Skeleton className="h-48 w-full" /></Card>
          </div>
        </div>
      ) : (
        <div className="space-y-5">

          {/* ================= KPI ================= */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              label="Total Aset" value={total} icon={TotalIcon} tone="neutral"
              hint="Seluruh aset terdaftar" to="/assets"
            />
            <StatCard
              label="Dipakai" value={statusMap.dipakai || 0} icon={InUseIcon} tone="info"
              progress={pct(statusMap.dipakai || 0)} to="/assets?status=dipakai"
            />
            <StatCard
              label="Menganggur" value={statusMap.idle || 0} icon={IdleIcon} tone="brand"
              progress={pct(statusMap.idle || 0)} to="/assets?status=idle"
            />
            <StatCard
              label="Dijual / Terjual" value={soldTotal} icon={SoldIcon} tone="warning"
              progress={pct(soldTotal)} to="/assets?status=dijual"
            />
          </div>

          {/* Aksi cepat — hanya di layar sempit, menggantikan tombol di kepala halaman */}
          <div className="flex sm:hidden gap-2 overflow-x-auto -mx-4 px-4 pb-1">
            {hasRole('admin', 'it_staff') && (
              <Button to="/assets/new" size="sm" className="shrink-0">
                <PlusIcon className="h-3.5 w-3.5" /> Tambah Aset
              </Button>
            )}
            <Button to="/assets?status=idle" variant="secondary" size="sm" className="shrink-0">Menganggur</Button>
            <Button to="/cetak-barcode-massal" variant="secondary" size="sm" className="shrink-0">Cetak Label</Button>
          </div>

          {/* ============ DONUT STATUS + AKTIVITAS TERBARU ============ */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <Card>
              <CardHeader
                title="Komposisi Status"
                description="Klik salah satu status untuk melihat daftarnya."
              />
              {total > 0 ? (
                <StatusDonut statusMap={statusMap} total={total} />
              ) : (
                <EmptyState
                  icon="fa-chart-pie"
                  title="Belum ada aset"
                  description="Tambahkan aset pertama untuk mulai melihat ringkasannya di sini."
                  action={hasRole('admin', 'it_staff') ? <Button to="/assets/new" size="sm">Tambah Aset</Button> : undefined}
                  className="py-8"
                />
              )}
            </Card>

            <Card className="lg:col-span-2" padded={false}>
              <CardHeader
                title="Aktivitas Terbaru"
                description="Sepuluh perubahan terakhir di seluruh sistem."
                bordered
              />
              <div className="p-5 sm:p-6">
                {summary.recentActivity.length > 0 ? (
                  <ul className="divide-y divide-ink-100">
                    {summary.recentActivity.map((a, i) => (
                      <ActivityItem key={`${a.created_at}-${i}`} entry={a} />
                    ))}
                  </ul>
                ) : (
                  <EmptyState
                    icon="fa-clock-rotate-left"
                    title="Belum ada aktivitas"
                    description="Perubahan data akan tercatat otomatis dan muncul di sini."
                    className="py-8"
                  />
                )}
              </div>
            </Card>
          </div>

          {/* ============ SEBARAN PER KODE BARANG/ASET ============ */}
          <Card padded={false}>
            <CardHeader
              title="Sebaran per Kode Barang/Aset"
              description="Kelompok barang dengan jumlah aset terbanyak."
              bordered
              action={hasRole('admin') ? (
                <Button to="/categories" variant="ghost" size="xs">Kelola</Button>
              ) : undefined}
            />
            <div className="p-5 sm:p-6">
              {categories.length > 0 ? (
                <ul className="space-y-4">
                  {categories.map((c) => {
                    const value = Number(c.total);
                    return (
                      <li key={c.category_name}>
                        <div className="flex items-baseline justify-between gap-3 mb-1.5">
                          <span className="text-[13px] font-medium text-ink-700 truncate">{c.category_name}</span>
                          <span className="text-[13px] text-ink-500 tabular-nums shrink-0">
                            <span className="font-semibold text-ink-800">{value}</span>
                            <span className="text-ink-400"> · {pct(value).toFixed(0)}%</span>
                          </span>
                        </div>
                        <div className="progress-track">
                          <div
                            className="progress-fill bg-gradient-to-r from-brand-500 to-info-500"
                            style={{ width: `${Math.max(3, (value / maxCategory) * 100)}%` }}
                          />
                        </div>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <EmptyState
                  icon="fa-tags"
                  title="Belum ada kode barang/aset terpakai"
                  description="Kode barang akan muncul di sini setelah ada aset yang memakainya."
                  className="py-8"
                />
              )}
            </div>
          </Card>
        </div>
      )}
    </Layout>
  );
}
