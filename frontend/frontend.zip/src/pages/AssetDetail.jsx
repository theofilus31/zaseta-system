import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout.jsx';
import axiosClient from '../api/axiosClient.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useNotification } from '../context/NotificationContext.jsx';
import Card, { CardHeader } from '../components/ui/Card.jsx';
import Button from '../components/ui/Button.jsx';
import PageHeader from '../components/ui/PageHeader.jsx';
import StatusBadge, { ConditionBadge, STATUS_CONFIG } from '../components/ui/StatusBadge.jsx';
import EmptyState from '../components/ui/EmptyState.jsx';
import { Skeleton } from '../components/ui/Skeleton.jsx';
import { parseSpecDetail } from '../utils/specDetail.js';

const rupiah = (v) =>
  v === null || v === undefined || v === '' ? null : `Rp ${Number(v).toLocaleString('id-ID')}`;

const tanggal = (v) =>
  v ? new Date(v).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : null;

/** Satu baris "label → nilai" dalam daftar deskripsi. */
function Info({ label, value, mono = false, wide = false }) {
  return (
    <div className={wide ? 'sm:col-span-2' : ''}>
      <dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">{label}</dt>
      <dd className={`text-sm text-ink-800 mt-1 ${mono ? 'font-mono' : 'font-medium'} break-words`}>
        {value || <span className="text-ink-300 font-normal">—</span>}
      </dd>
    </div>
  );
}

/**
 * Detail Spesifikasi: kalau isinya list bernomor (1. 2. 3. …) tampil menurun
 * sebagai daftar dan melebar penuh; kalau bukan, tampil seperti Info biasa.
 */
function SpecDetailInfo({ value }) {
  if (!value || !value.trim()) return <Info label="Detail Spesifikasi" value={null} />;

  const parsed = parseSpecDetail(value);

  if (parsed.isList) {
    return (
      <div className="sm:col-span-2">
        <dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">Detail Spesifikasi</dt>
        <dd className="mt-2">
          <ul className="space-y-1.5">
            {parsed.items.map((item, i) => (
              <li key={i} className="flex gap-2.5 text-sm text-ink-700">
                <span className="mt-0.5 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-md bg-ink-100 text-[10px] font-bold text-ink-500 tabular-nums">
                  {i + 1}
                </span>
                <span className="min-w-0">{item}</span>
              </li>
            ))}
          </ul>
        </dd>
      </div>
    );
  }

  return (
    <div className="sm:col-span-2">
      <dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">Detail Spesifikasi</dt>
      <dd className="text-sm text-ink-800 font-medium mt-1 whitespace-pre-line">{value}</dd>
    </div>
  );
}

export default function AssetDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasRole } = useAuth();
  const { pushError, pushSuccess } = useNotification();

  const [asset, setAsset] = useState(null);
  const [regenerating, setRegenerating] = useState(false);
  const [deleting, setDeleting] = useState(false);

  function load() {
    return axiosClient.get(`/assets/${id}`).then((res) => setAsset(res.data));
  }

  useEffect(() => { load(); }, [id]);

  async function handleRegenerateQr() {
    if (!confirm('Kode QR lama tidak akan berlaku lagi setelah ini. Lanjutkan?')) return;
    setRegenerating(true);
    try {
      await axiosClient.post(`/assets/${id}/qr/regenerate`);
      await load();
      pushSuccess('Kode QR berhasil dibuat ulang. Label lama perlu dicetak ulang.');
    } catch (err) {
      pushError(err.response?.data?.message || 'Gagal membuat ulang Kode QR.');
    } finally {
      setRegenerating(false);
    }
  }

  async function handleDelete() {
    if (!confirm('Hapus aset ini? Tindakan ini tidak bisa dibatalkan.')) return;
    setDeleting(true);
    try {
      await axiosClient.delete(`/assets/${id}`);
      navigate('/assets');
    } catch (err) {
      pushError(err.response?.data?.message || 'Gagal menghapus aset.');
      setDeleting(false);
    }
  }

  /* ---------- Keadaan memuat ---------- */
  if (!asset) {
    return (
      <Layout>
        <Skeleton className="h-4 w-24 mb-3" />
        <Skeleton className="h-7 w-64 mb-2" />
        <Skeleton className="h-4 w-40 mb-7" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-5">
            <Card><Skeleton className="h-4 w-32 mb-5" /><Skeleton className="h-40 w-full" /></Card>
            <Card><Skeleton className="h-4 w-32 mb-5" /><Skeleton className="h-24 w-full" /></Card>
          </div>
          <Card><Skeleton className="h-44 w-full" /></Card>
        </div>
      </Layout>
    );
  }

  const location = [asset.location_name, asset.sub_location_name].filter(Boolean).join(' · ') || asset.location;
  const originLocation = [asset.origin_location_name, asset.origin_sub_location_name].filter(Boolean).join(' · ');
  const activeCustomFields = (asset.customFields || []).filter((cf) => cf.value_text);

  return (
    <Layout>
      <PageHeader
        backTo="/assets"
        backLabel="Daftar Aset"
        eyebrow={asset.category_name}
        title={asset.name}
        description={
          <span className="font-mono text-ink-600">{asset.asset_code}</span>
        }
        actions={
          <>
            <Button to={`/assets/${id}/qr`} variant="secondary" size="sm">
              <i className="fas fa-qrcode text-xs" aria-hidden="true" /> Cetak Label
            </Button>
            {hasRole('admin', 'it_staff') && (
              <Button to={`/assets/${id}/edit`} size="sm">
                <i className="fas fa-pen text-xs" aria-hidden="true" /> Ubah Aset
              </Button>
            )}
            {hasRole('admin') && (
              <Button variant="destructive" size="sm" onClick={handleDelete} loading={deleting}>
                {deleting ? 'Menghapus…' : <><i className="fas fa-trash-can text-xs" aria-hidden="true" /> Hapus</>}
              </Button>
            )}
          </>
        }
      />

      {/* Peringatan khusus aset berstatus "dipindah" — konteks paling penting
          diletakkan sebelum detail, bukan terkubur di dalam daftar. */}
      {asset.status === 'dipindah' && originLocation && (
        <div className="mb-5 flex items-start gap-3 rounded-2xl border border-accent-200 bg-accent-50 px-4 py-3.5">
          <i className="fas fa-route mt-0.5 text-accent-600 shrink-0" aria-hidden="true" />
          <div className="min-w-0 text-sm">
            <p className="font-semibold text-accent-800">Aset sedang dalam status dipindahkan</p>
            <p className="text-accent-700 mt-0.5 leading-relaxed">
              Lokasi asal: <span className="font-medium">{originLocation}</span>. Status hanya bisa
              dikembalikan ke Dipakai/Menganggur setelah lokasi diatur persis seperti lokasi asal.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 items-start">

        {/* ================= KOLOM UTAMA ================= */}
        <div className="lg:col-span-2 space-y-5 order-2 lg:order-1">

          <Card>
            <CardHeader title="Identitas Aset" description="Informasi utama yang menempel pada aset ini." />
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5">
              <Info label="Kategori Aset" value={asset.asset_type_name} />
              <div>
                <dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">Kondisi Fisik</dt>
                <dd className="mt-1.5"><ConditionBadge condition={asset.condition_status} /></dd>
              </div>
              <Info label="Brand" value={asset.brand} />
              <Info label="Model" value={asset.model} />
              <Info label="Nomor Seri" value={asset.serial_number} mono />
              <Info label="Lokasi" value={location} />
              <SpecDetailInfo value={asset.spec_detail} />
            </dl>
          </Card>

          <Card>
            <CardHeader title="Informasi Keuangan" description="Riwayat pembelian dan penjualan aset." />
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5">
              <Info label="Vendor" value={asset.vendor} />
              <Info label="Tanggal Beli" value={tanggal(asset.purchase_date)} />
              <Info label="Harga Beli" value={rupiah(asset.purchase_price)} />
              <Info label="Harga Jual / Net" value={rupiah(asset.sale_value_net)} />
              <Info label="Tanggal Terjual" value={tanggal(asset.sold_date)} />
              <Info label="Harga Terjual" value={rupiah(asset.sold_price)} />
            </dl>
          </Card>

          {activeCustomFields.length > 0 && (
            <Card>
              <CardHeader title="Bidang Kustom" description="Informasi tambahan khusus kode barang/aset ini." />
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5">
                {activeCustomFields.map((cf) => (
                  <Info key={cf.field_id} label={cf.field_label} value={cf.value_text} />
                ))}
              </dl>
            </Card>
          )}

          {asset.notes && (
            <Card>
              <CardHeader title="Catatan" />
              <p className="text-sm text-ink-600 leading-relaxed whitespace-pre-line">{asset.notes}</p>
            </Card>
          )}

          {/* ---------- Riwayat status sebagai garis waktu ---------- */}
          <Card padded={false}>
            <CardHeader
              title="Riwayat Status"
              description="Setiap perubahan status tercatat otomatis."
              bordered
            />
            <div className="p-5 sm:p-6">
              {asset.statusHistory.length > 0 ? (
                <ol className="relative space-y-5">
                  {/* Garis vertikal penghubung titik-titik riwayat */}
                  <span className="absolute left-[7px] top-2 bottom-2 w-px bg-ink-200" aria-hidden="true" />
                  {asset.statusHistory.map((h, i) => {
                    const cfg = STATUS_CONFIG[h.new_status];
                    return (
                      <li key={i} className="relative flex gap-4 pl-0">
                        <span
                          className="relative z-10 mt-1 h-[15px] w-[15px] shrink-0 rounded-full border-[3px] border-white ring-1 ring-ink-200"
                          style={{ backgroundColor: cfg?.chart || '#94a3b8' }}
                          aria-hidden="true"
                        />
                        <div className="min-w-0 flex-1 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                          <p className="text-sm text-ink-700">
                            {h.old_status ? (
                              <>
                                <span className="text-ink-500">{STATUS_CONFIG[h.old_status]?.label || h.old_status}</span>
                                <i className="fas fa-arrow-right text-[9px] text-ink-300 mx-2" aria-hidden="true" />
                                <span className="font-semibold text-ink-800">{cfg?.label || h.new_status}</span>
                              </>
                            ) : (
                              <>Dibuat dengan status <span className="font-semibold text-ink-800">{cfg?.label || h.new_status}</span></>
                            )}
                          </p>
                          <p className="text-[11px] text-ink-400 tabular-nums shrink-0">
                            {new Date(h.changed_at).toLocaleString('id-ID', {
                              day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
                            })}
                          </p>
                        </div>
                      </li>
                    );
                  })}
                </ol>
              ) : (
                <EmptyState
                  icon="fa-clock-rotate-left"
                  title="Belum ada riwayat"
                  description="Perubahan status aset ini akan muncul di sini."
                  className="py-6"
                />
              )}
            </div>
          </Card>
        </div>

        {/* ================= KOLOM SAMPING ================= */}
        <div className="space-y-5 order-1 lg:order-2 lg:sticky lg:top-20">

          <Card className="text-center">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-400 mb-3">Status Saat Ini</p>
            <StatusBadge status={asset.status} size="lg" />
          </Card>

          {asset.qr && (
            <Card className="text-center">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-400 mb-4">Kode QR Aset</p>

              {asset.qr.image_path ? (
                <div className="inline-block rounded-2xl border border-ink-200 bg-white p-3 shadow-sm">
                  <img src={asset.qr.image_path} alt={`Kode QR untuk ${asset.name}`} className="h-36 w-36" />
                </div>
              ) : (
                <p className="text-xs text-danger-600 py-8">Gambar Kode QR tidak valid.</p>
              )}

              <p className="text-xs text-ink-400 mt-3.5">
                Sudah dipindai <span className="font-semibold text-ink-600 tabular-nums">{asset.qr.scan_count}</span> kali
              </p>

              <div className="flex flex-col gap-2 mt-4">
                <Button to={`/assets/${id}/qr`} variant="secondary" size="sm" block>
                  <i className="fas fa-print text-xs" aria-hidden="true" /> Cetak Label
                </Button>
                {hasRole('admin', 'it_staff') && (
                  <Button variant="ghost" size="sm" block onClick={handleRegenerateQr} loading={regenerating}>
                    {regenerating ? 'Membuat ulang…' : 'Buat Ulang Kode QR'}
                  </Button>
                )}
              </div>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
