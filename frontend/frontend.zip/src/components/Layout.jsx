import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar, { SidebarDrawer, navItems } from './layout/Sidebar.jsx';
import Topbar from './layout/Topbar.jsx';
import BottomTabBar from './layout/BottomTabBar.jsx';
import ErrorToast from './layout/ErrorToast.jsx';

export default function Layout({ children, width = 'default' }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const location = useLocation();

  /* Judul di Topbar diambil dari menu yang cocok dengan URL sekarang.
     Dulu ini membaca `window.location.pathname` langsung — nilainya tidak ikut
     berubah saat navigasi antar halaman karena React tidak me-render ulang
     komponen ini. `useLocation()` memastikan judulnya selalu ikut berpindah. */
  const activeNav = navItems.find((item) => location.pathname.startsWith(item.to));

  const maxWidth = {
    default: 'max-w-[1400px]',
    narrow: 'max-w-3xl',
    full: 'max-w-none',
  }[width] || 'max-w-[1400px]';

  return (
    <div className="h-screen bg-ink-50 flex">

      {/* Sidebar tetap di layar lebar */}
      <aside className="hidden lg:flex w-64 shrink-0">
        <Sidebar />
      </aside>

      {/* Laci sidebar di layar sempit */}
      <SidebarDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />

      {/* Area konten utama */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <Topbar title={activeNav?.label || ''} onMenuClick={() => setDrawerOpen(true)} />

        <main className="flex-1 overflow-y-auto scrollbar-slim pb-20 lg:pb-0">
          <div className={`${maxWidth} mx-auto px-4 sm:px-6 py-5 sm:py-7`}>
            {children}
          </div>
        </main>

        <BottomTabBar onMoreClick={() => setDrawerOpen(true)} />
      </div>

      {/* Notifikasi mengambang di pojok kanan atas */}
      <ErrorToast />
    </div>
  );
}
