import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import NotificationHistoryDropdown from './NotificationHistoryDropdown.jsx';

function useClock() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(interval);
  }, []);

  return now;
}

export default function Topbar({ title, onMenuClick }) {
  const navigate = useNavigate();
  const now = useClock();

  const timeLabel = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  const dateLabel = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const iconButton =
    'h-9 w-9 flex items-center justify-center rounded-lg text-ink-500 ' +
    'hover:bg-ink-100 hover:text-ink-700 transition-colors shrink-0';

  return (
    <header
      className="h-16 shrink-0 sticky top-0 z-30 flex items-center justify-between gap-3
                 border-b border-ink-200/70 bg-white/85 backdrop-blur-md px-4 sm:px-6"
    >
      <div className="flex items-center gap-2 min-w-0">
        {/* Buka laci navigasi (layar sempit) */}
        <button onClick={onMenuClick} aria-label="Buka menu navigasi" className={`lg:hidden -ml-1 ${iconButton}`}>
          <i className="fas fa-bars text-base" aria-hidden="true" />
        </button>

        {/* Kembali (layar lebar) */}
        <button onClick={() => navigate(-1)} aria-label="Kembali" title="Kembali" className={`hidden lg:flex -ml-1 ${iconButton}`}>
          <i className="fas fa-arrow-left text-sm" aria-hidden="true" />
        </button>

        {/* Logo ringkas menggantikan judul di layar sempit, karena sidebar tersembunyi */}
        <img
          src="/logo-rms-icon.png"
          alt="RMS"
          className="lg:hidden h-7 w-auto object-contain shrink-0 ml-1"
        />

        <h1 className="hidden sm:block text-[15px] font-semibold text-ink-700 truncate ml-1">
          {title}
        </h1>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        {/* Jam & tanggal — konteks berguna saat mencatat mutasi aset */}
        <div className="hidden md:flex flex-col items-end leading-tight select-none">
          <span className="text-[13px] font-semibold text-ink-700 tabular-nums">{timeLabel}</span>
          <span className="text-[11px] text-ink-400">{dateLabel}</span>
        </div>

        <div className="hidden md:block h-6 w-px bg-ink-200" aria-hidden="true" />

        <NotificationHistoryDropdown />
      </div>
    </header>
  );
}
