import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';

/**
 * ============================================================================
 *  NAVIGASI UTAMA
 * ============================================================================
 *  Menu dikelompokkan menurut cara kerja sehari-hari, bukan menurut urutan
 *  tabel di database:
 *
 *   - Operasional : yang dibuka setiap hari oleh staf IT
 *   - Master Data : acuan yang jarang berubah (dipakai untuk menyusun kode aset)
 *   - Administrasi: pengaturan pengguna
 *
 *  Tanpa pengelompokan, delapan menu berderet rata terasa sama penting semua
 *  dan pekerjaan harian tenggelam di antara menu pengaturan.
 * ============================================================================
 */
export const navGroups = [
  {
    label: 'Operasional',
    items: [
      { to: '/dashboard', label: 'Dasbor', icon: 'fa-chart-pie', roles: ['admin', 'it_staff', 'viewer'] },
      { to: '/assets', label: 'Daftar Aset', icon: 'fa-laptop', roles: ['admin', 'it_staff', 'viewer'] },
      { to: '/cetak-barcode-massal', label: 'Cetak Kode Batang', icon: 'fa-print', roles: ['admin', 'it_staff', 'viewer'] },
    ],
  },
  {
    label: 'Master Data',
    items: [
      { to: '/categories', label: 'Kode Barang/Aset', icon: 'fa-tags', roles: ['admin'] },
      { to: '/asset-types', label: 'Kategori Aset', icon: 'fa-layer-group', roles: ['admin'] },
      { to: '/locations', label: 'Lokasi', icon: 'fa-location-dot', roles: ['admin'] },
      { to: '/custom-fields', label: 'Bidang Kustom', icon: 'fa-list-ul', roles: ['admin'] },
    ],
  },
  {
    label: 'Administrasi',
    items: [
      { to: '/users', label: 'Manajemen Pengguna', icon: 'fa-user-shield', roles: ['admin'] },
    ],
  },
];

/* Versi datar — dipakai Layout untuk mencari judul halaman aktif dan oleh
   BottomTabBar untuk menyusun tab di layar sempit. */
export const navItems = navGroups.flatMap((g) => g.items);

const ROLE_LABEL = {
  admin: 'Administrator',
  it_staff: 'Staf IT',
  viewer: 'Peninjau',
};

export default function Sidebar({ onNavigate }) {
  const { user, logout, hasRole } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/login');
  }

  const visibleGroups = navGroups
    .map((group) => ({ ...group, items: group.items.filter((item) => hasRole(...item.roles)) }))
    .filter((group) => group.items.length > 0);

  return (
    <div className="flex flex-col h-full w-full bg-white border-r border-ink-200/70">

      {/* ===== KEPALA: LOGO ===== */}
      {/* Tingginya disamakan dengan Topbar (h-16) supaya garis border sejajar */}
      <div className="h-16 px-5 flex items-center gap-3 border-b border-ink-200/70 shrink-0">
        <img src="/logo-rms-icon.png" alt="" aria-hidden="true" className="h-9 w-auto object-contain shrink-0" />
        <div className="min-w-0">
          <p className="text-[15px] font-bold text-ink-900 tracking-tight leading-tight truncate">
            Asset Inventory
          </p>
          <p className="text-[11px] text-ink-400 truncate">PT Rukun Mitra Sejati</p>
        </div>
      </div>

      {/* ===== MENU ===== */}
      <nav className="flex-1 px-3 py-5 overflow-y-auto scrollbar-slim space-y-6">
        {visibleGroups.map((group) => (
          <div key={group.label}>
            <p className="px-3 mb-2 text-[10px] font-bold uppercase tracking-[0.08em] text-ink-400">
              {group.label}
            </p>
            <div className="space-y-0.5">
              {group.items.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  onClick={onNavigate}
                  className={({ isActive }) =>
                    [
                      'group relative flex items-center gap-3 px-3 py-2.5 rounded-xl',
                      'text-[13.5px] font-medium transition-all duration-150',
                      isActive
                        ? 'bg-brand-500 text-white shadow-brand-sm'
                        : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900',
                    ].join(' ')
                  }
                >
                  {({ isActive }) => (
                    <>
                      <i
                        className={`fas ${item.icon} w-4 text-center text-[13px] shrink-0 transition-colors ${
                          isActive ? 'text-white' : 'text-ink-400 group-hover:text-ink-600'
                        }`}
                        aria-hidden="true"
                      />
                      <span className="truncate">{item.label}</span>
                    </>
                  )}
                </NavLink>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* ===== KAKI: KARTU PENGGUNA ===== */}
      <div className="p-3 border-t border-ink-200/70 shrink-0">
        <div className="flex items-center gap-2 rounded-xl bg-ink-50 p-2 border border-ink-200/60">
          <button
            onClick={() => { navigate('/profile'); onNavigate?.(); }}
            title="Buka profil saya"
            className="flex items-center gap-2.5 flex-1 min-w-0 text-left rounded-lg px-1 py-1
                       hover:bg-white transition-colors"
          >
            <span
              className="h-9 w-9 shrink-0 rounded-full bg-gradient-to-br from-info-500 to-brand-500
                         flex items-center justify-center text-white font-semibold text-sm shadow-sm"
              aria-hidden="true"
            >
              {user?.name?.[0]?.toUpperCase() || '?'}
            </span>
            <span className="flex-1 min-w-0">
              <span className="block text-[13px] font-semibold text-ink-800 truncate">{user?.name}</span>
              <span className="block text-[11px] text-ink-400 truncate">
                {ROLE_LABEL[user?.role] || user?.role}
              </span>
            </span>
          </button>

          <button
            onClick={handleLogout}
            title="Keluar"
            aria-label="Keluar"
            className="shrink-0 h-8 w-8 flex items-center justify-center rounded-lg
                       text-ink-400 hover:text-danger-600 hover:bg-danger-50 transition-colors"
          >
            <i className="fas fa-right-from-bracket text-[13px]" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   LACI SIDEBAR UNTUK LAYAR SEMPIT
   ========================================================= */
export function SidebarDrawer({ open, onClose }) {
  return (
    <div className={`fixed inset-0 z-40 lg:hidden ${open ? '' : 'pointer-events-none'}`}>
      <div
        className={`absolute inset-0 bg-ink-900/50 backdrop-blur-sm transition-opacity duration-200 ${
          open ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className={`absolute inset-y-0 left-0 w-72 max-w-[82vw] shadow-overlay
                    transition-transform duration-200 ease-out ${open ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <Sidebar onNavigate={onClose} />
      </div>
    </div>
  );
}
