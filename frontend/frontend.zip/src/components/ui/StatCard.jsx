import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Kartu KPI untuk Dasbor.
 *
 * Kalau diberi prop `to`, seluruh kartu jadi tautan — dipakai supaya angka di
 * dasbor langsung bisa diklik menuju daftar aset yang sudah terfilter, bukan
 * cuma jadi pajangan.
 */

const TONES = {
  brand:   { icon: 'bg-brand-50 text-brand-600',     bar: 'bg-brand-500',   value: 'text-ink-900' },
  info:    { icon: 'bg-info-50 text-info-600',       bar: 'bg-info-500',    value: 'text-ink-900' },
  warning: { icon: 'bg-warning-50 text-warning-600', bar: 'bg-warning-500', value: 'text-ink-900' },
  danger:  { icon: 'bg-danger-50 text-danger-600',   bar: 'bg-danger-500',  value: 'text-ink-900' },
  accent:  { icon: 'bg-accent-50 text-accent-600',   bar: 'bg-accent-500',  value: 'text-ink-900' },
  neutral: { icon: 'bg-ink-100 text-ink-500',        bar: 'bg-ink-400',     value: 'text-ink-900' },
};

export default function StatCard({
  label,
  value,
  icon: Icon,
  tone = 'brand',
  hint,
  progress,
  to,
  className = '',
}) {
  const t = TONES[tone] || TONES.brand;
  const Tag = to ? Link : 'div';
  const tagProps = to ? { to } : {};

  return (
    <Tag
      {...tagProps}
      className={[
        'stat-card group block bg-white rounded-2xl border border-ink-200/70 shadow-card p-5',
        to ? 'hover:border-brand-300 cursor-pointer' : '',
        className,
      ].join(' ')}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[13px] font-medium text-ink-500 truncate">{label}</p>
          <p className={`text-[28px] leading-none font-bold mt-2 tabular-nums ${t.value}`}>{value}</p>
        </div>
        {Icon && (
          <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${t.icon}`}>
            <Icon className="h-[22px] w-[22px]" />
          </span>
        )}
      </div>

      {hint && <p className="text-xs text-ink-400 mt-2.5 truncate">{hint}</p>}

      {typeof progress === 'number' && (
        <div className="mt-4">
          <div className="progress-track">
            <div
              className={`progress-fill ${t.bar}`}
              style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
            />
          </div>
          <p className="text-[11px] text-ink-400 mt-1.5 tabular-nums">
            {progress.toFixed(progress % 1 === 0 ? 0 : 1)}% dari total aset
          </p>
        </div>
      )}
    </Tag>
  );
}
