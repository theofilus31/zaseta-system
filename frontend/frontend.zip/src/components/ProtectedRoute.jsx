import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Layout from './Layout.jsx';
import Card from './ui/Card.jsx';
import Button from './ui/Button.jsx';
import EmptyState from './ui/EmptyState.jsx';

/**
 * allowedRoles kosong = semua peran yang sudah masuk boleh mengakses.
 *
 * Catatan: pembatasan di sini hanya untuk kenyamanan tampilan. Otorisasi yang
 * sebenarnya tetap divalidasi di backend (middleware/auth.js → requireRole),
 * jadi permintaan API tetap ditolak sekalipun UI ini dilewati.
 */
export default function ProtectedRoute({ children, allowedRoles = [] }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return (
      <Layout width="narrow">
        <Card className="mt-6">
          <EmptyState
            icon="fa-lock"
            tone="warning"
            title="Halaman ini tidak tersedia untuk Anda"
            description="Peran akun Anda tidak memiliki izin untuk membuka halaman ini. Hubungi administrator bila Anda merasa seharusnya punya akses."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <Button to="/dashboard" size="sm">Kembali ke Dasbor</Button>
                <Button to="/assets" variant="secondary" size="sm">Lihat Daftar Aset</Button>
              </div>
            }
          />
        </Card>
      </Layout>
    );
  }

  return children;
}
