import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import AssetList from './pages/AssetList.jsx';
import AssetDetail from './pages/AssetDetail.jsx';
import AssetForm from './pages/AssetForm.jsx';
import CategoryManagement from './pages/CategoryManagement.jsx';
import AssetTypeManagement from './pages/AssetTypeManagement.jsx';
import LocationManagement from './pages/LocationManagement.jsx';
import CustomFieldManagement from './pages/CustomFieldManagement.jsx';
import UserManagement from './pages/UserManagement.jsx';
import Profile from './pages/Profile.jsx';
import QRPrintPage from './pages/QRPrintPage.jsx';
import BatchQrPrintPage from './pages/BatchQrPrintPage.jsx';
import PublicScanPage from './pages/PublicScanPage.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

export default function App() {
  return (
    <Routes>
      {/* Publik — tidak butuh login, ini yang diakses saat client scan QR */}
      <Route path="/scan/:code" element={<PublicScanPage />} />

      <Route path="/login" element={<Login />} />

      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

      <Route path="/assets" element={<ProtectedRoute><AssetList /></ProtectedRoute>} />
      <Route path="/assets/new" element={<ProtectedRoute allowedRoles={['admin', 'it_staff']}><AssetForm /></ProtectedRoute>} />
      <Route path="/cetak-barcode-massal" element={<ProtectedRoute><BatchQrPrintPage /></ProtectedRoute>} />
      <Route path="/assets/:id" element={<ProtectedRoute><AssetDetail /></ProtectedRoute>} />
      <Route path="/assets/:id/edit" element={<ProtectedRoute allowedRoles={['admin', 'it_staff']}><AssetForm /></ProtectedRoute>} />
      <Route path="/assets/:id/qr" element={<ProtectedRoute><QRPrintPage /></ProtectedRoute>} />

      <Route path="/categories" element={<ProtectedRoute allowedRoles={['admin']}><CategoryManagement /></ProtectedRoute>} />
      <Route path="/asset-types" element={<ProtectedRoute allowedRoles={['admin']}><AssetTypeManagement /></ProtectedRoute>} />
      <Route path="/locations" element={<ProtectedRoute allowedRoles={['admin']}><LocationManagement /></ProtectedRoute>} />
      <Route path="/custom-fields" element={<ProtectedRoute allowedRoles={['admin']}><CustomFieldManagement /></ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute allowedRoles={['admin']}><UserManagement /></ProtectedRoute>} />

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
